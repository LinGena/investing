export declare function send<T = unknown>(type: string, args?: {}): Promise<T>;
