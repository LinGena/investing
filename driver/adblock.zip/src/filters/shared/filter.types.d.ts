export declare enum FilterOrigin {
    popup = "popup",
    web = "web",
    devtools = "devtools",
    wizard = "wizard",
    youtube = "youtube",
    customize = "customize",
    context = "context"
}
