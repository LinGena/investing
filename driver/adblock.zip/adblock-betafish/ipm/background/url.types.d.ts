export declare enum ExperimentSearchParameterKeys {
    revision = "er",
    variants = "ev"
}
export declare const noRevisionId = "";
