export declare function createSafeOriginUrl(url: string): string | null;
export declare function addExperimentsSearchParams(url: string): Promise<string | null>;
