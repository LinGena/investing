export function OptionsList({ items, isChecked, onItemChange }: {
    items: any;
    isChecked: any;
    onItemChange: any;
}): import("react").JSX.Element;
