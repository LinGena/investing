export function AcceptableAdsList({ subs }: {
    subs: any;
}): import("react").JSX.Element;
