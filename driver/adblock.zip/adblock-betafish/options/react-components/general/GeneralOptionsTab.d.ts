export function GeneralOptionsTab({ subs, settings, prefs }: {
    subs: any;
    settings: any;
    prefs: any;
}): import("react").JSX.Element;
