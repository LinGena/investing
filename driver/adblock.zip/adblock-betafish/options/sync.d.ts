declare function onSyncDataInitialGetError(): Promise<void>;
