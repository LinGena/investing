export function processMessageResponse(sendResponse: any, responseData: any): Promise<any>;
