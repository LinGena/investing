declare class DataCollectionV2 {
    static start: () => Promise<unknown>;
    static end: () => Promise<unknown>;
}
