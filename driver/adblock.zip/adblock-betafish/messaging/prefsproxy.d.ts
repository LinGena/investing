declare function initializePrefs(): Promise<void>;
declare const prefsNotifier: EventEmitter;
declare const localprefs: {};
declare let Prefs: {};
declare let abpPrefPropertyNames: {};
