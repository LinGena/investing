import { LocaleInfo } from "./locale.types";
export declare function getLocaleInfo(): LocaleInfo;
