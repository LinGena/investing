export function startTelemetryOptOutListener(): Promise<void>;
export const IPM: IPMTelemetry;
export const TELEMETRY: Telemetry;
import IPMTelemetry from "./telemetry-ipm";
import Telemetry from "./telemetry-ping";
