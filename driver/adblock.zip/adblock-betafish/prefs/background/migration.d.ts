declare namespace _default {
    export { migrateUserData };
}
export default _default;
declare function migrateUserData(): Promise<void>;
