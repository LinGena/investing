export default FoodChannel;
declare class FoodChannel extends Channel {
    getLatestListings(callback: any): void;
}
import Channel from "./channel";
