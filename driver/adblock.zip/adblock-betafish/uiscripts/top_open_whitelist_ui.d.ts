declare function topOpenWhitelistUI(options: any): void;
