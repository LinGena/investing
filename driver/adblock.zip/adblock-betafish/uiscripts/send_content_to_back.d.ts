declare function sendContentToBack(): void;
