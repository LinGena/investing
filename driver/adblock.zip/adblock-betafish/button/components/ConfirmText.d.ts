export default class ConfirmText extends HTMLElement {
    connectedCallback(): Promise<void>;
    pageInfo: any;
}
