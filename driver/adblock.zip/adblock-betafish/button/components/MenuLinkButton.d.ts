export default class MenuLinkButton extends HTMLElement {
    connectedCallback(): Promise<void>;
    pageInfo: any;
}
