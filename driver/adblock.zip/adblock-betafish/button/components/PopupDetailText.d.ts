export default class PopupDetailText extends HTMLElement {
    connectedCallback(): Promise<void>;
}
