export default class SubNav extends HTMLElement {
    connectedCallback(): Promise<void>;
}
