export default class Toggle extends HTMLElement {
    connectedCallback(): void;
}
