export function getUserFilters(): Promise<ewe.Filter[]>;
import * as ewe from "@eyeo/webext-ad-filtering-solution";
