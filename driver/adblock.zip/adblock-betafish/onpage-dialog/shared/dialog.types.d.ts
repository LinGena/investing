export interface DialogContent {
    body: string[];
    button: string;
    title: string;
}
