export function showOptions(message?: Object | undefined): Promise<void>;
