export type subscriptionsGetInitIssuesResult = {
    dataCorrupted: boolean;
    reinitialized: boolean;
};
export const initialize: Promise<any>;
export function isDataCorrupted(): boolean;
