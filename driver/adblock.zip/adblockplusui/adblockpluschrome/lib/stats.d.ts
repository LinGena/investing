export function getBlockedPerPage(page: Page): number;
export namespace Stats {
    function on(stat: string, callback: Function): void;
    function on(stat: string, callback: Function): void;
    function off(stat: string, callback: Function): void;
    function off(stat: string, callback: Function): void;
}
