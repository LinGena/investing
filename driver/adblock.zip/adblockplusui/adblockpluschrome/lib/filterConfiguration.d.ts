export function addFilter(filterText: any, origin: any): Promise<unknown>;
export function askConfirmSubscription(details: Object): Promise<void>;
export function initDisabledFilterCounters(): Promise<void>;
